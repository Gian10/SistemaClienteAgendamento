const express = require('express')
const router = express.Router()

const userService = require('../services/userService')
const schedulingService = require('../services/schedulingService')
const passport = require('../config/passport')()

router.route('/scheduling')
    .all(passport.authenticate())
    .get((req, res)=>{
        const db = req.app.get('db')
        schedulingService.getScheduling(db, req.query.usuario_id)
        .then(schedulin => res.status(200).send(schedulin))
        .catch(_ => res.status(500).send('ERRO AO BUSCAR AGENDAMENTO'))
    })

    .post(async(req, res) =>{
        const db = req.app.get('db')
        const userScheduling = { ...req.body}

        const userId = await userService.getUserId(db, userScheduling.usuario_id)
        let celular = userId[0].celular
        let email = userId[0].email
        userScheduling['celular'] = celular
        userScheduling['email'] = email
        userScheduling['cancelado'] = false

        schedulingService.postScheduling(db, userScheduling)
        .then(_ => res.status(201).send('SALVO!'))
        .catch(_ => res.status(500).send('ERRO AO SALVAR!'))
    })

    router.route('/scheduling/:data')
        .all(passport.authenticate())
        .get((req, res)=>{
            const db = req.app.get('db')
            schedulingService.getDateScheduling(db, req.params.data)
            .then(hora => res.status(201).send(hora))
            .catch(_ => res.status(500).send('ERRO AO REALIZAR BUSCA!'))
        })

    router.route('/scheduling/cancelar/:id')
        .all(passport.authenticate())
        .put((req, res)=>{
            const db = req.app.get('db')
            schedulingService.cancellationScheduling(db, req.params.id)
            .then(_ => res.status(201).send('CANCELADO COM SUCESSO!'))
            .catch(_ => res.status(500).send('ERRO AO CANCELAR!'))
        })

    module.exports = router