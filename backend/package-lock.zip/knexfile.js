// Update with your config settings.

module.exports = {

    client: 'postgresql',
    connection: {
      host: 'projetogh.c9dcevvoihpi.us-east-2.rds.amazonaws.com',
      port: '5432',
      database: 'projetogh',
      user:     'postgres',
      password: 'senha123'
    },
    pool: {
      min: 2,
      max: 10
    },
    migrations: {
      tableName: 'knex_migrations'
    }
  }
